export interface ScreeningByOverTime {
  Screened: number;
  EpiWeek: string;
}