export interface EnrollmentByAgeGender {
  EnrolledNumber: number;
  Gender: string;
  AgeGroup: string;
}