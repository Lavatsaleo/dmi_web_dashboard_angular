export interface Covid19ResultsByPositivityOverTime {
  SampleTested: number;
  Covid19Positive: number;
  EpiWeek: number;
  Month: number;
  Year: number;
}