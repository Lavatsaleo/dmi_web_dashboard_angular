export interface EnrollmentOverTime {
  ElligibleNumber: number;
  EnrolledNumber: number;
  EpiWeek: number;
  Month: number;
  Year: string;
}