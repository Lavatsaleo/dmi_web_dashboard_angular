export interface CovidPositivity {
  Covid19Positive: number;
  Covid19Negative: number;
}
