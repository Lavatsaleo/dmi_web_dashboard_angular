export interface ScreeningByFacility {
     Screened: number;
     Enrolled: number;
     Covid19Positive: number;
     Facility: string;
}