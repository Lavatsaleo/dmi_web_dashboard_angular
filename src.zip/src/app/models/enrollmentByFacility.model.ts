export interface EnrollmentByFacility {
  EnrolledNumber: number;
  Covid19Positive: number;
  Facility: string;
}