export interface Covid19ResultsByFacility {
  Facility: string;
  SampleTested: number;
  Covid19Positive: number;
  Covid19Negative: number;
}

