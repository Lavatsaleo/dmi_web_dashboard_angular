export interface Covid19ResultsByAgeGender {
  Gender: string;
  AgeGroup: string;
  Covid19Positive: number;
}