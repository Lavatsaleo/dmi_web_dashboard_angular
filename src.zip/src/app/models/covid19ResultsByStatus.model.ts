export interface Covid19ResultsByStatus {
  Covid19Positive: number;
  Covid19Negative: number;
}

