export interface ScreeningByGender {
    Male_Screened: number;
    Female_Screened: number;
    Male_Eligible: number;
    Female_Eligible: number;
    Male_Enrolled: number;
    Female_Enrolled: number;
}