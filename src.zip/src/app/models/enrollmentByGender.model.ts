export interface EnrollmentByGender {
  EnrolledMale: number;
  EnrolledFemale: number;
  
  TestedMale: number;
  TestedFemale: number;
  
  PositiveMale: number;
  PositiveFemale: number;
}