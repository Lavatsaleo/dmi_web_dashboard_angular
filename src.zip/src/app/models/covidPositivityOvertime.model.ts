export interface CovidPositivityOvertime {
  EpiWeek: number;
  SampleTested: Number;
  CovidPositive: number;
}