export interface ScreeningByAgeGender {
  Screened: number;
  Gender: string;
  AgeGroup: string;
}