export interface NumEnrolled {
  female: number;
  male: number;
}

