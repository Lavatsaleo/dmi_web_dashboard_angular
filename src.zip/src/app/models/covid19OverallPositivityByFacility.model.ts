export interface Covid19OverallPositivityByFacility {
  EnrolledNumber: number;
  Covid19Positive: number;
  Facility: string;
}
