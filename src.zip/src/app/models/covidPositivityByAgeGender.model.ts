export interface CovidPositivityByAgeGender {
  PositiveNumber: number;
  Gender: string;
  AgeGroup: string;
}