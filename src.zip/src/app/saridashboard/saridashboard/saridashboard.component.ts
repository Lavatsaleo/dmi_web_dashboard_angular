import { Component } from '@angular/core';

@Component({
  selector: 'app-saridashboard',
  templateUrl: './saridashboard.component.html',
  styleUrls: ['./saridashboard.component.css']
})
export class SaridashboardComponent {

}
