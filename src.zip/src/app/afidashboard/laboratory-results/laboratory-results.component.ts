import { Component } from '@angular/core';

@Component({
  selector: 'app-laboratory-results',
  templateUrl: './laboratory-results.component.html',
  styleUrls: ['./laboratory-results.component.css']
})
export class LaboratoryResultsComponent {

}
