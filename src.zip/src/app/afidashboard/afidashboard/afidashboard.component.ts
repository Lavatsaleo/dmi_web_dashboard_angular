import { Component } from '@angular/core';

@Component({
  selector: 'app-afidashboard',
  templateUrl: './afidashboard.component.html',
  styleUrls: ['./afidashboard.component.css']
})
export class AfidashboardComponent {

}
