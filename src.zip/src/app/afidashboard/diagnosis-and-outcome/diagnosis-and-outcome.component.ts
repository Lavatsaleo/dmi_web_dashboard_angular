import { Component } from '@angular/core';

@Component({
  selector: 'app-diagnosis-and-outcome',
  templateUrl: './diagnosis-and-outcome.component.html',
  styleUrls: ['./diagnosis-and-outcome.component.css']
})
export class DiagnosisAndOutcomeComponent {

}
