import { Component } from '@angular/core';

@Component({
  selector: 'app-syndromic-cases',
  templateUrl: './syndromic-cases.component.html',
  styleUrls: ['./syndromic-cases.component.css']
})
export class SyndromicCasesComponent {

}
